import pandas as pd
import matplotlib.pyplot as plt
from sklearn.cluster import KMeans

# Langkah 1: Persiapan Data
covid_data = pd.read_excel('data_covid.xlsx')  # Ganti dengan lokasi data COVID-19 Anda

# Langkah 2: K-Means Clustering
num_clusters = 3  # Ganti dengan jumlah klaster yang sesuai
features = covid_data[['Positif', 'Sembuh', 'Meninggal']]  # Ganti dengan fitur-fitur yang relevan
kmeans = KMeans(n_clusters=num_clusters)
covid_data['cluster'] = kmeans.fit_predict(features)

import pandas as pd
import matplotlib.pyplot as plt
from sklearn.cluster import KMeans

# Langkah 1: Persiapan Data
covid_data = pd.read_excel('data_covid.xlsx')  # Ganti dengan lokasi data COVID-19 Anda

# Langkah 2: K-Means Clustering
num_clusters = 3  # Ganti dengan jumlah klaster yang sesuai
features = covid_data[['Positif', 'Sembuh', 'Meninggal']]  # Ganti dengan fitur-fitur yang relevan
kmeans = KMeans(n_clusters=num_clusters)
covid_data['cluster'] = kmeans.fit_predict(features)

# Skema warna untuk visualisasi data
data_colors = ['red', 'yellow', 'green']

# Skema warna untuk visualisasi klaster
cluster_colors = ['green', 'yellow', 'red']

plt.figure(figsize=(10, 4))

# Visualisasi Data dalam Pie Chart
plt.subplot(1, 2, 1)
status_counts = covid_data[['Positif', 'Sembuh', 'Meninggal']].sum()
total_cases = status_counts.sum()
status_percentages = status_counts / total_cases * 100
status_percentages_ordered = [status_percentages['Positif'], status_percentages['Meninggal'], status_percentages['Sembuh']]
labels = ['Positif', 'Meninggal', 'Sembuh']
plt.pie(status_percentages_ordered, labels=labels, colors=data_colors, autopct='%1.1f%%', startangle=140)
plt.axis('equal')
plt.title('Persentase Status Covid-19')

# Visualisasi Klaster dalam Pie Chart
plt.subplot(1, 2, 2)
cluster_counts = covid_data['cluster'].value_counts()
cluster_percentages = cluster_counts / cluster_counts.sum() * 100
cluster_percentages_ordered = [cluster_percentages[0], cluster_percentages[2], cluster_percentages[1]]
cluster_labels = [f'Cluster 1', f'Cluster 3', f'Cluster 2']
plt.pie(cluster_percentages_ordered, labels=cluster_labels, colors=cluster_colors, autopct='%1.1f%%', startangle=140)
plt.axis('equal')
plt.title('Persentase Klastering Status Covid-19')

plt.tight_layout()
plt.show()
